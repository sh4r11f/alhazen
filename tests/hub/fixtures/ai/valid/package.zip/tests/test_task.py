"""Tests for fixation_flash_hold, using alhazen's public test doubles."""

from __future__ import annotations

import numpy as np
import pytest

from alhazen import Duration, InputFrame
from alhazen.core.engine import TrialEngine
from alhazen.core.events import EventBus
from alhazen.core.trial import TrialContext
from alhazen.testing import EventCollector, FakeClock, FakeDisplay, ScriptedCommands, ScriptedInputs
from alhazen.display.screen import Screen

from fixation_flash_hold.task import FixationFlashHoldTask, FixationFlashHoldTaskParams

FRAME_S = 1 / 60
SCREEN = Screen(width_px=1920, height_px=1080, px_per_deg=40.0)

LOOKING = InputFrame(gaze=(0.0, 0.0))
AWAY = InputFrame(gaze=(900.0, 900.0))
BLINK = InputFrame(gaze=None)


def run_trial(task, inputs, condition_params=None):
    clock = FakeClock()
    display = FakeDisplay(clock, FRAME_S)
    bus = EventBus()
    collector = EventCollector()
    bus.subscribe(collector)
    engine = TrialEngine(
        display=display,
        clock=clock,
        bus=bus,
        schema=task.events,
        commands=ScriptedCommands(),
        input_provider=ScriptedInputs(inputs),
    )

    from alhazen.config.loader import build_session_config
    from alhazen.config.models import (
        DisplayConfig,
        MonitorConfig,
        RigConfig,
        SessionInfo,
    )
    from alhazen.paradigms.base import Condition
    from alhazen.task.plan import TrialSetup

    monitor = MonitorConfig(
        width_px=1920, height_px=1080, width_cm=60.0, distance_cm=60.0,
        refresh_rate_hz=60.0, fullscreen=False,
    )
    params = task.params
    if condition_params is None:
        condition_params = {"flash": True}
    setup = TrialSetup(
        cfg=build_session_config(
            RigConfig(monitor=monitor, display=DisplayConfig(backend="simulated"), data_root="."),
            SessionInfo(subject="t01", session=1, run=1, task_name=task.name, seed=1),
            params,
            {},
        ),
        screen=SCREEN,
        display=display,
        rng=np.random.default_rng(0),
        refresh_rate_hz=1 / FRAME_S,
        trial_index=1,
        attempt=1,
        condition=Condition(condition_params),
    )
    plan = task.build_trial(setup)
    ctx = TrialContext(
        clock=clock,
        screen=SCREEN,
        rng=np.random.default_rng(0),
        trial_index=1,
        params=dict(setup.condition.params),
        stimuli=plan.stimuli,
        regions=plan.regions,
        record=dict(plan.record),
    )
    return collector, engine.run_trial(ctx, plan.phases)


@pytest.fixture
def task():
    return FixationFlashHoldTask(
        FixationFlashHoldTaskParams(
            acquire_timeout=Duration(frames=10),
            hold_duration=Duration(frames=6),
            flash_duration=Duration(frames=3),
        )
    )


def test_parameter_loading():
    path = FixationFlashHoldTask.default_params()
    from alhazen.config.loader import load_params

    params = load_params(path, FixationFlashHoldTaskParams)
    assert params.acquire_timeout.ms == 2000
    assert params.hold_duration.ms == 1000
    assert params.flash_duration.ms == 100
    assert params.flash_eccentricity_dva == 8
    assert params.flash_size_dva == 1.0
    assert params.fix_size_dva == 2.0
    assert params.fix_window_dva == 2.0


def test_timeline_structure(task):
    # Build a trial and check phases and parameters
    from alhazen.task.phases import AcquireFixation, HoldFixation, Feedback, Blank

    setup = task.conditions(np.random.default_rng())[0]
    # Use a dummy TrialSetup
    class DummySetup:
        def __init__(self):
            self.refresh_rate_hz = 60
            self.condition = setup
            self.screen = SCREEN
            self.display = None

    dummy_setup = DummySetup()
    plan = task.build_trial(dummy_setup)

    # Check phases types and order
    phase_types = [type(p).__name__ for p in plan.phases]
    assert "AcquireFixation" in phase_types
    assert phase_types.count("HoldFixation") == 2
    assert any(isinstance(p, Feedback) or isinstance(p, Blank) for p in plan.phases)


def test_condition_counts(task):
    conds = task.conditions(np.random.default_rng())
    assert len(conds) == 2
    flash_counts = sum(1 for c in conds if c.params.get("flash", False))
    no_flash_counts = sum(1 for c in conds if not c.params.get("flash", False))
    assert flash_counts == 1
    assert no_flash_counts == 1


def test_simulated_trial_execution(task):
    # Simulate a trial with gaze fixating throughout
    inputs = [LOOKING] * 20
    collector, result = run_trial(task, inputs, condition_params={"flash": True})
    assert result.outcome.name == "FIXATED"
    assert "FIX_ON" in collector.names()
    assert "FIX_ACQUIRED" in collector.names()
    assert "FLASH_ON" in collector.names()

    collector, result = run_trial(task, inputs, condition_params={"flash": False})
    assert result.outcome.name == "FIXATED"
    assert "FIX_ON" in collector.names()
    assert "FIX_ACQUIRED" in collector.names()
    # No FLASH_ON event expected
    assert "FLASH_ON" not in collector.names()


def test_fixation_break_during_hold(task):
    # Blink during hold causes FIX_BREAK
    inputs = [LOOKING] * 5 + [BLINK] + [LOOKING] * 5
    collector, result = run_trial(task, inputs, condition_params={"flash": True})
    assert result.outcome.name == "FIX_BREAK"

    collector, result = run_trial(task, inputs, condition_params={"flash": False})
    assert result.outcome.name == "FIX_BREAK"
