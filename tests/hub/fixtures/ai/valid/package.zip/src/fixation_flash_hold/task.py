"""The experiment: fixation-flash-hold task with a peripheral flash stimulus on half the trials."""

from __future__ import annotations

from pathlib import Path

import numpy as np

from alhazen import (
    CircleRegion,
    Condition,
    Duration,
    Model,
    Task,
    TrialPlan,
    TrialSetup,
    outcomes,
)
from alhazen.core.events import EventSchema
from alhazen.paradigms.config import SchedulerConfig
from alhazen.stimuli.fixation import make_fixation
from alhazen.task import phases
from alhazen.task.subject_kind import SubjectParams


class FixationFlashHoldTaskParams(SubjectParams):
    paradigm: SchedulerConfig = SchedulerConfig(kind="sequence", n_per_condition=20)
    acquire_timeout: Duration = Duration(ms=2000)
    hold_duration: Duration = Duration(ms=1000)
    flash_duration: Duration = Duration(ms=100)
    flash_eccentricity_dva: float = 8.0
    flash_size_dva: float = 1.0
    fix_size_dva: float = 2.0
    fix_window_dva: float = 2.0
    iti: Duration = Duration(ms=500)  # Inter-trial interval, default 500 ms


class FixationFlashHoldTask(Task):
    name = "fixation-flash-hold"

    events = EventSchema(("FIX_ON", "FIX_ACQUIRED", "FLASH_ON"))

    outcomes = outcomes(
        FIXATED=dict(completed=True, success=True),
        NO_FIXATION=dict(completed=True, success=False),
        FIX_BREAK=dict(completed=False),
    )

    params_model = FixationFlashHoldTaskParams

    @classmethod
    def default_params(cls) -> Path:
        repository = Path(__file__).resolve().parents[2]
        return repository / "configs" / "task.yaml"

    def instructions(self) -> str | None:
        return (
            "Look at the dot in the middle of the screen, and keep your eyes on it.\n"
            "\n"
            "Press SPACE to begin."
        )

    def conditions(self, rng: np.random.Generator) -> list[Condition]:
        # Two conditions: flash and no_flash, served equally
        return [Condition({"flash": True}), Condition({"flash": False})]

    def build_trial(self, setup: TrialSetup) -> TrialPlan:
        params: FixationFlashHoldTaskParams = self.params  # type: ignore[assignment]
        hz = setup.refresh_rate_hz

        # Fixation stimulus
        fixation = make_fixation(setup.display, setup.screen, params.fix_size_dva)

        # Flash stimulus: a bright white circle at eccentricity to the right
        # Position in px: convert eccentricity dva to px
        flash_x = params.flash_eccentricity_dva
        flash_y = 0.0
        flash_radius_px = setup.screen.deg2px(params.flash_size_dva) / 2.0

        flash_stimulus = make_fixation(
            setup.display,
            setup.screen,
            params.flash_size_dva,
            pos=(setup.screen.deg2px(flash_x), flash_y),
        )

        # Regions
        fixation_region = CircleRegion(
            (0.0, 0.0), setup.screen.deg2px(params.fix_window_dva)
        )

        # Trial phases
        phases_list = [
            phases.AcquireFixation(
                timeout_s=params.acquire_timeout.seconds(hz),
                on_timeout=self.outcomes["NO_FIXATION"],
            ),
            phases.HoldFixation(
                duration_s=params.hold_duration.seconds(hz) / 2.0,
                on_break=self.outcomes["FIX_BREAK"],
                onset_event="FIX_ACQUIRED",
            ),
        ]

        # Flash phase only on flash trials
        if setup.condition.params.get("flash", False):
            phases_list.append(
                phases.HoldFixation(
                    duration_s=params.flash_duration.seconds(hz),
                    on_break=self.outcomes["FIX_BREAK"],
                    concurrent=["flash"],
                    onset_event="FLASH_ON",
                    duration_record_key="flash_hold_s",
                )
            )
        else:
            # No flash: hold fixation for the same time, with nothing added
            phases_list.append(
                phases.HoldFixation(
                    duration_s=params.flash_duration.seconds(hz),
                    on_break=self.outcomes["FIX_BREAK"],
                    duration_record_key="flash_hold_s",
                )
            )

        # Hold fixation after flash for remaining hold duration
        phases_list.append(
            phases.HoldFixation(
                duration_s=params.hold_duration.seconds(hz) / 2.0,
                on_break=self.outcomes["FIX_BREAK"],
                onset_event=None,
            )
        )

        # End trial with FIXATED outcome
        phases_list.append(phases.Blank(0.0, then=self.outcomes["FIXATED"]))

        return TrialPlan(
            phases=phases_list,
            stimuli={"fixation": fixation, "flash": flash_stimulus},
            regions={"fixation": fixation_region},
        )

    def demo_views(self, setup):
        from alhazen.modes.demo import DemoView

        params: FixationFlashHoldTaskParams = self.params  # type: ignore[assignment]
        fixation = make_fixation(setup.display, setup.screen, params.fix_size_dva)

        def draw_fixation(elapsed):
            fixation.draw()

        return [
            DemoView(
                name="fixation",
                caption="Fixation point at session size",
                draw=draw_fixation,
            )
        ]

    def movie_clips(self, setup):
        from alhazen.modes.movie import MovieClip

        params: FixationFlashHoldTaskParams = self.params  # type: ignore[assignment]

        def frames():
            screen = setup.screen
            radius = screen.deg2px(params.fix_size_dva) / 2.0
            rows, cols = np.mgrid[0 : screen.height_px, 0 : screen.width_px]
            centre_r = (screen.height_px - 1) / 2.0
            centre_c = (screen.width_px - 1) / 2.0
            frame = np.full((screen.height_px, screen.width_px), 0.5, dtype=np.float32)
            frame[(cols - centre_c) ** 2 + (rows - centre_r) ** 2 <= radius**2] = 1.0
            hold_frames = round(params.hold_duration.seconds(setup.hz) * setup.hz)
            for _ in range(hold_frames):
                yield frame

        return [MovieClip(name="fixation-hold", frames=frames)]

    def simulation(self, seed: int):
        from alhazen.devices.automated import AutomatedGazeTracker
        from alhazen.modes.simulation import Simulation

        return Simulation(
            tracker=AutomatedGazeTracker(),
            describe={"seed": seed, "source": "alhazen.devices.automated"},
        )
