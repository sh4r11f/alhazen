# Fixation Hold with Peripheral Flash

This experiment measures whether a subject can maintain fixation through a brief peripheral flash. The subject fixates a central point and holds fixation. On half the trials, a brief flash appears peripherally during the hold.

## Running the Experiment

Use the provided `run.py` script or `alhazen run` commands.

### Demo mode

```bash
python run.py --task fixation-flash-hold --mode demo
```

Shows the stimuli without running trials or collecting data.

### Movie mode

```bash
python run.py --task fixation-flash-hold --mode movie --rig configs/rig-lab.yaml --out movies
```

Records the stimulus presentation to movie files.

### Measure mode

```bash
python run.py --task fixation-flash-hold --mode measure --rig configs/rig-lab.yaml
```

Measures the rig's display, response keys, and eye tracker.

### Simulate mode

```bash
python run.py --task fixation-flash-hold --mode simulate --rig configs/rig-lab.yaml --seed 1 --headless
```

Runs a simulated session with an automated gaze tracker.

### Test mode

```bash
python run.py --task fixation-flash-hold --mode test --rig configs/rig-mac.yaml --sub dev --ses 1 --initials DEV
```

Runs a short session for testing.

### Run mode

```bash
python run.py --task fixation-flash-hold --rig configs/rig-lab.yaml --sub s01 --ses 1 --initials AB
```

Runs the full experiment with a human subject.

## Requirements

- Alhazen 2.13.0 or later
- Rig configuration files

## Files

- `src/fixation_flash_hold/task.py`: task implementation
- `configs/task.yaml`: parameters
- `tests/test_task.py`: tests
- `run.py`: script to run the experiment

## License

MIT
