Each trial begins with the fixation point appearing at the center of the screen. The subject must acquire fixation within [[param:acquire_timeout]] (2000 ms). Once fixation is acquired, the subject holds fixation for [[param:hold_duration]] (1000 ms) before the flash.

On half the trials, a brief peripheral flash stimulus appears for [[param:flash_duration]] (100 ms) at 8 dva to the right of fixation during the hold period. On the other half, no flash is presented.

After the flash, fixation must be held for the remainder of the hold duration. Any gaze leaving the fixation window during acquisition or hold ends the trial with the appropriate outcome.

Successful fixation acquisition and hold through the flash results in outcome FIXATED. Failure to acquire fixation results in NO_FIXATION. Breaking fixation during hold results in FIX_BREAK and the trial is repeated.

