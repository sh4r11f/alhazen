This package implements the fixation-flash-hold task, a gaze-contingent experiment where the subject fixates a central point and holds fixation. On half the trials, a brief peripheral flash stimulus is presented during the fixation hold period; on the other half, no flash is presented. The task measures whether fixation is maintained through the flash.

## Purpose

To measure the subject's ability to maintain fixation through a brief peripheral flash presented during a fixation hold.

## Apparatus

Display geometry, refresh rate, eye tracker, and data root are provided by the rig configuration. The fixation point is at the center of the screen, and the flash stimulus is presented peripherally at 8 dva eccentricity to the right.

## Stimuli

- Fixation point: a filled white circle, 2.0 dva diameter, at screen center.
- Flash stimulus: a bright flash, 1.0 dva diameter, presented briefly (100 ms) at 8 dva to the right of fixation.

## Procedure

Each trial begins with the fixation point appearing and the subject required to acquire fixation within 2000 ms. Once fixation is acquired, the subject must hold fixation for 1000 ms before the flash. On flash trials, the flash stimulus appears for 100 ms during the hold period. After the flash, fixation must be held for the remainder of the hold duration. Trials end with an outcome indicating whether fixation was maintained.

## Design

Two conditions: flash and no_flash, served equally by a sequence scheduler with 20 trials per condition (40 trials total). Trials that do not complete (e.g., fixation breaks) are repeated rather than counted.

## Measures

- Outcome: whether fixation was successfully held through the flash or no flash.
- Acquisition latency (seconds).
- Hold duration (seconds).
- Post-flash hold duration (seconds): time from flash onset to fixation break or hold end.

## References

- alhazen-vision 2.13.0 or later, the toolkit this package is built on (https://github.com/sh4r11f/alhazen).
